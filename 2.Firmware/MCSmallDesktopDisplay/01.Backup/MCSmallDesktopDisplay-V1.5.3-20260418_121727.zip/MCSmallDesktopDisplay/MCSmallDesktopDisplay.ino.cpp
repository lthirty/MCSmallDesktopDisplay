# 1 "C:\\Users\\lthir\\AppData\\Local\\Temp\\tmp21ssb0sq"
#include <Arduino.h>
# 1 "F:/05.理财/31.商品/10.正式商品化/07.WIFI天气小时钟SmallDesktopDisplay/2.Firmware/MCSmallDesktopDisplay/MCSmallDesktopDisplay.ino"
# 73 "F:/05.理财/31.商品/10.正式商品化/07.WIFI天气小时钟SmallDesktopDisplay/2.Firmware/MCSmallDesktopDisplay/MCSmallDesktopDisplay.ino"
#define Version "V1.5.3"



#include "ArduinoJson.h"
#include <TimeLib.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266WebServer.h>
#include <WiFiUdp.h>
#include <ESP8266mDNS.h>
#include <TFT_eSPI.h>
#include <SPI.h>
#include <TJpg_Decoder.h>
#include <EEPROM.h>
#include <LittleFS.h>
#include "qr.h"
#include "number.h"
#include "weathernum.h"






#define WM_EN 1

#define WebSever_EN 1





#define DHT_EN 1

#define imgAst_EN 1



#if WM_EN
#include <WiFiManager.h>

WiFiManager wm;

#endif

#if DHT_EN
#include "DHT.h"
#define DHTPIN 12
#define DHTTYPE DHT11
DHT dht(DHTPIN,DHTTYPE);
#endif
# 133 "F:/05.理财/31.商品/10.正式商品化/07.WIFI天气小时钟SmallDesktopDisplay/2.Firmware/MCSmallDesktopDisplay/MCSmallDesktopDisplay.ino"
#include "font/ZdyLwFont_20.h"
#include "img/boot_logo_lianli.h"
#include "img/config_tip_cn.h"
#include "img/indoor_lianli.h"
#include "img/temperature.h"
#include "img/humidity.h"

#if imgAst_EN
#include "img/pangzi/i0.h"
#include "img/pangzi/i1.h"
#include "img/pangzi/i2.h"
#include "img/pangzi/i3.h"
#include "img/pangzi/i4.h"
#include "img/pangzi/i5.h"
#include "img/pangzi/i6.h"
#include "img/pangzi/i7.h"
#include "img/pangzi/i8.h"
#include "img/pangzi/i9.h"

int Anim = 0;
int AprevTime = 0;
#endif







struct config_type
{
  char stassid[32];
  char stapsw[64];
};



config_type wificonf ={{""},{""}};


int updateweater_time = 10;
int LCD_Rotation = 0;
int LCD_BL_PWM = 8;
String cityCode = "101010100";



TFT_eSPI tft = TFT_eSPI();
TFT_eSprite clk = TFT_eSprite(&tft);
#define LCD_BL_PIN 5
uint16_t bgColor = 0x0000;
const int RUN_IMG_X = 170;
const int RUN_IMG_Y = 175;
const int RUN_IMG_W = 60;
const int RUN_IMG_H = 54;

File webUploadFile;
String webUploadError = "";
uint32_t webUploadBytes = 0;
uint32_t webWrittenBytes = 0;
uint8_t bootLogoDrawn = 0;


uint8_t Wifi_en = 1;
uint8_t UpdateWeater_en = 0;
int prevTime = 0;
int DHT_img_flag = 0;
uint8_t indoorAvatarDirty = 1;



int BL_addr = 1;
int Ro_addr = 2;
int DHT_addr = 3;
int UpWeT_addr = 4;
int CC_addr = 10;
int wifi_addr = 30;
int Warn_Number1 = 0,Warn_Value1 = 0,Warn_Number2 = 0,Warn_Value2 = 0,Warn_Flag = 1;
time_t prevDisplay = 0;
unsigned long weaterTime = 0;
String SMOD = "";



Number dig;
WeatherNum wrat;


uint32_t targetTime = 0;

int tempnum = 0;
int huminum = 0;
int tempcol =0xffff;
int humicol =0xffff;


ESP8266WebServer server(80);



static const char ntpServerName[] = "ntp6.aliyun.com";
const int timeZone = 8;


WiFiUDP Udp;
WiFiClient wificlient;
unsigned int localPort = 8000;
float duty=0;



time_t getNtpTime();
void digitalClockDisplay(int reflash_en);
void printDigits(int digits);
String num2str(int digits);
void sendNTPpacket(IPAddress &address);
void LCD_reflash(int en);
void savewificonfig();
void readwificonfig();
void deletewificonfig();
bool isJpgFileName(const String& filename);
bool drawCustomJpegInBox(const char* path, int x, int y, int boxW, int boxH);
bool validateUploadedJpeg(const char* path, String& err);
void drawBootLogo();
void drawRuntimeCornerImage();
void handleBootUpload();
void handleRunUpload();
#if WebSever_EN
void Web_Sever_Init();
void Web_Sever();
#endif
void saveCityCodetoEEP(int * citycode);
void readCityCodefromEEP(int * citycode);
int getCityCodeByName(String cityName);





void saveCityCodetoEEP(int * citycode)
{
  for(int cnum=0;cnum<5;cnum++)
  {
    EEPROM.write(CC_addr+cnum,*citycode%100);
    EEPROM.commit();
    *citycode = *citycode/100;
    delay(5);
  }
}
void readCityCodefromEEP(int * citycode)
{
  for(int cnum=5;cnum>0;cnum--)
  {
    *citycode = *citycode*100;
    *citycode += EEPROM.read(CC_addr+cnum-1);
    delay(5);
  }
}

int getCityCodeByName(String cityName)
{
  cityName.trim();
  cityName.replace(" ", "");
  if(cityName.endsWith("市")) cityName.remove(cityName.length() - 1);
  if(cityName == "北京") return 101010100;
  if(cityName == "上海") return 101020100;
  if(cityName == "广州") return 101280101;
  if(cityName == "深圳") return 101280601;
  if(cityName == "杭州") return 101210101;
  if(cityName == "南京") return 101190101;
  if(cityName == "武汉") return 101200101;
  if(cityName == "西安") return 101110101;
  if(cityName == "重庆") return 101040100;
  if(cityName == "成都") return 101270101;
  if(cityName == "长沙") return 101250101;
  if(cityName == "珠海") return 101280701;
  return 0;
}


void savewificonfig()
{

  uint8_t *p = (uint8_t*)(&wificonf);
  for (int i = 0; i < sizeof(wificonf); i++)
  {
    EEPROM.write(i + wifi_addr, *(p + i));
  }
  delay(10);
  EEPROM.commit();
  delay(10);
}

void deletewificonfig()
{
  config_type deletewifi ={{""},{""}};
  uint8_t *p = (uint8_t*)(&deletewifi);
  for (int i = 0; i < sizeof(deletewifi); i++)
  {
    EEPROM.write(i + wifi_addr, *(p + i));
  }
  delay(10);
  EEPROM.commit();
  delay(10);
}


void readwificonfig()
{
  uint8_t *p = (uint8_t*)(&wificonf);
  for (int i = 0; i < sizeof(wificonf); i++)
  {
    *(p + i) = EEPROM.read(i + wifi_addr);
  }



  Serial.printf("Read WiFi Config.....\r\n");
  Serial.printf("SSID:%s\r\n",wificonf.stassid);
  Serial.printf("PSW:%s\r\n",wificonf.stapsw);
  Serial.printf("Connecting.....\r\n");
}
bool tft_output(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t* bitmap);
void loading(byte delayTime);
void humidityWin();
void tempWin();
void IndoorTem();
void SmartConfig(void);
void Serial_set();
void handleconfig();
void handleNotFound();
void Web_sever_Win();
void Web_win();
void Webconfig();
String getParam(String name);
void saveParamCallback();
void setup();
void loop();
void getCityCode();
void getCityWeater();
void weaterData(String *cityDZ,String *dataSK,String *dataFC,String *dataWarn1);
void scrollBanner();
void imgAnim();
String week();
String monthDay();
#line 357 "F:/05.理财/31.商品/10.正式商品化/07.WIFI天气小时钟SmallDesktopDisplay/2.Firmware/MCSmallDesktopDisplay/MCSmallDesktopDisplay.ino"
bool tft_output(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t* bitmap)
{
  if ( y >= tft.height() ) return 0;
  tft.pushImage(x, y, w, h, bitmap);

  return 1;
}

bool isJpgFileName(const String& filename)
{
  String lower = filename;
  lower.toLowerCase();
  return lower.endsWith(".jpg") || lower.endsWith(".jpeg");
}

bool drawCustomJpegInBox(const char* path, int x, int y, int boxW, int boxH)
{
  if(!LittleFS.exists(path)) return false;

  tft.fillRect(x, y, boxW, boxH, bgColor);
  uint16_t w = 0, h = 0;
  JRESULT sizeJr = TJpgDec.getFsJpgSize(&w, &h, path, LittleFS);
  if(sizeJr == JDR_OK && w > 0 && h > 0)
  {
    int scale = 1;
    while(scale < 8 && ((int)(w / (scale * 2)) > boxW || (int)(h / (scale * 2)) > boxH)) scale *= 2;
    int drawW = (int)(w / scale);
    int drawH = (int)(h / scale);
    int drawX = x + (boxW - drawW) / 2;
    int drawY = y + (boxH - drawH) / 2;
    TJpgDec.setJpgScale(scale);
    JRESULT jr = TJpgDec.drawFsJpg(drawX, drawY, path, LittleFS);
    TJpgDec.setJpgScale(1);
    return jr == JDR_OK;
  }

  TJpgDec.setJpgScale(1);
  JRESULT jr = TJpgDec.drawFsJpg(x, y, path, LittleFS);
  TJpgDec.setJpgScale(1);
  return jr == JDR_OK;
}

bool validateUploadedJpeg(const char* path, String& err)
{
  if(!LittleFS.exists(path))
  {
    err = "Upload failed: file not found";
    return false;
  }

  File f = LittleFS.open(path, "r");
  if(!f)
  {
    err = "Upload failed: file open error";
    return false;
  }

  uint8_t b1 = f.read();
  uint8_t b2 = f.read();
  size_t sz = f.size();
  f.close();
  if(sz < 16)
  {
    err = "Upload failed: file content invalid";
    return false;
  }
  if(!(b1 == 0xFF && b2 == 0xD8))
  {
    err = "Upload failed: not JPEG";
    return false;
  }

  uint16_t w = 0, h = 0;
  JRESULT jr = TJpgDec.getFsJpgSize(&w, &h, path, LittleFS);
  if(jr != JDR_OK)
  {
    err = "Upload failed: JPEG parse error";
    return false;
  }
  return true;
}

void drawBootLogo()
{
  if(!drawCustomJpegInBox("/boot.jpg", 20, 64, 200, 70))
    TJpgDec.drawJpg(20, 64, boot_logo_lianli, sizeof(boot_logo_lianli));
}

void drawRuntimeCornerImage()
{
  if(!drawCustomJpegInBox("/run.jpg", RUN_IMG_X, RUN_IMG_Y, RUN_IMG_W, RUN_IMG_H))
  {
    tft.fillRect(RUN_IMG_X, RUN_IMG_Y, RUN_IMG_W, RUN_IMG_H, bgColor);
    TJpgDec.drawJpg(RUN_IMG_X, RUN_IMG_Y, indoor_lianli, sizeof(indoor_lianli));
  }
}


byte loadNum = 6;
void loading(byte delayTime)
{

  if(!bootLogoDrawn){ drawBootLogo(); bootLogoDrawn = 1; }

  clk.setColorDepth(8);

  clk.createSprite(220, 70);
  clk.fillSprite(0x0000);

  clk.drawRoundRect(0,0,220,16,8,0xFFFF);
  clk.fillRoundRect(3,3,loadNum,10,5,0xFFFF);
  clk.setTextDatum(CC_DATUM);
  clk.setTextColor(TFT_GREEN, 0x0000);
  clk.drawString("Connecting WiFi...",110,44,4);
  clk.setTextColor(TFT_WHITE, 0x0000);
  clk.pushSprite(10,150);





  clk.deleteSprite();
  loadNum += 1;
  delay(delayTime);
}


void humidityWin()
{
  clk.setColorDepth(8);

  huminum = huminum/2;
  clk.createSprite(52, 6);
  clk.fillSprite(0x0000);
  clk.drawRoundRect(0,0,52,6,3,0xFFFF);
  clk.fillRoundRect(1,1,huminum,4,2,humicol);
  clk.pushSprite(45,222);
  clk.deleteSprite();
}


void tempWin()
{
  clk.setColorDepth(8);

  clk.createSprite(52, 6);
  clk.fillSprite(0x0000);
  clk.drawRoundRect(0,0,52,6,3,0xFFFF);
  clk.fillRoundRect(1,1,tempnum,4,2,tempcol);
  clk.pushSprite(45,192);
  clk.deleteSprite();
}

#if DHT_EN

void IndoorTem()
{
  if(!indoorAvatarDirty) return;


  drawRuntimeCornerImage();
  indoorAvatarDirty = 0;
}
#endif

#if !WM_EN

void SmartConfig(void)
{
  WiFi.mode(WIFI_STA);

  tft.pushImage(0, 0, 240, 240, qr);
  Serial.println("\r\nWait for Smartconfig...");
  WiFi.beginSmartConfig();
  while (1)
  {
    Serial.print(".");
    delay(100);
    if (WiFi.smartConfigDone())
    {
    Serial.println("SmartConfig Success");
    Serial.printf("SSID:%s\r\n", WiFi.SSID().c_str());
    Serial.printf("PSW:%s\r\n", WiFi.psk().c_str());
    break;
    }
  }
  loadNum = 194;
}
#endif



void Serial_set()
{
  String incomingByte = "";
  if(Serial.available()>0)
  {

    while(Serial.available()>0)
    {
      incomingByte += char(Serial.read());
      delay(2);
    }
    if(SMOD=="0x01")
    {
      int LCDBL = atoi(incomingByte.c_str());
      if(LCDBL>=0 && LCDBL<=100)
      {
        EEPROM.write(BL_addr, LCDBL);
        EEPROM.commit();
        delay(5);
        LCD_BL_PWM = EEPROM.read(BL_addr);
        delay(5);
        SMOD = "";
        Serial.printf("亮度调整为：");
        analogWrite(LCD_BL_PIN, 1023 - (LCD_BL_PWM*10));
        Serial.println(LCD_BL_PWM);
        Serial.println("");
      }
      else
        Serial.println("亮度调整错误，请输入0-100");
    }
    if(SMOD=="0x02")
    {
      int CityCODE = 0;
      int CityC = atoi(incomingByte.c_str());
      if(CityC>=101000000 && CityC<=102000000 || CityC == 0)
      {
        saveCityCodetoEEP(&CityC);







        readCityCodefromEEP(&CityC);







        cityCode = CityCODE;

        if(cityCode == "0")
        {
          Serial.println("城市代码调整为：自动");
          getCityCode();
        }
        else
        {
          Serial.printf("城市代码调整为：");
          Serial.println(cityCode);
        }
        Serial.println("");
        getCityWeater();
        SMOD = "";
      }
      else
        Serial.println("城市调整错误，请输入9位城市代码，自动获取请输入0");
    }
    if(SMOD=="0x03")
    {
      int RoSet = atoi(incomingByte.c_str());
      if(RoSet >= 0 && RoSet <= 3)
      {
        EEPROM.write(Ro_addr, RoSet);
        EEPROM.commit();
        SMOD = "";

        tft.setRotation(RoSet);
        tft.fillScreen(0x0000);
        indoorAvatarDirty = 1;
        LCD_reflash(1);
        UpdateWeater_en = 1;
        TJpgDec.drawJpg(15,183,temperature, sizeof(temperature));
        TJpgDec.drawJpg(15,213,humidity, sizeof(humidity));

        Serial.print("屏幕方向设置为：");
        Serial.println(RoSet);
      }
      else
      {
        Serial.println("屏幕方向值错误，请输入0-3内的值");
      }
    }
    if(SMOD=="0x04")
    {
      int wtup = atoi(incomingByte.c_str());
      if(wtup>=1 && wtup<=60)
      {
        EEPROM.write(UpWeT_addr, wtup);
        EEPROM.commit();
        delay(5);
        updateweater_time = wtup;
        SMOD = "";
        Serial.printf("天气更新时间更改为：");
        Serial.print(updateweater_time);
        Serial.println("分钟");
      }
      else
        Serial.println("更新时间太长，请重新设置（1-60）");
    }
    else
    {
      SMOD = incomingByte;
      delay(2);
      if(SMOD=="0x01")
        Serial.println("请输入亮度值，范围0-100");
      else if(SMOD=="0x02")
        Serial.println("请输入9位城市代码，自动获取请输入0");
      else if(SMOD=="0x03")
      {
        Serial.println("请输入屏幕方向值，");
        Serial.println("0-USB接口朝下");
        Serial.println("1-USB接口朝右");
        Serial.println("2-USB接口朝上");
        Serial.println("3-USB接口朝左");
      }
      else if(SMOD=="0x04")
      {
        Serial.print("当前天气更新时间：");
        Serial.print(updateweater_time);
        Serial.println("分钟");
        Serial.println("请输入天气更新时间（1-60）分钟");
      }
      else if(SMOD=="0x05")
      {
        Serial.println("重置WiFi设置中......");
        delay(10);
        wm.resetSettings();
        deletewificonfig();
        delay(10);
        Serial.println("重置WiFi成功");
        SMOD = "";
        ESP.restart();
      }
      else
      {
        Serial.println("");
        Serial.println("请输入需要修改的代码：");
        Serial.println("亮度设置输入        0x01");
        Serial.println("地址设置输入        0x02");
        Serial.println("屏幕方向设置输入    0x03");
        Serial.println("更改天气更新时间    0x04");
        Serial.println("重置WiFi(会重启)    0x05");
        Serial.println("");
      }
    }
  }
}

#if WebSever_EN


void handleconfig()
{
  bool bootOk = server.hasArg("boot_upload_ok");
  bool runOk = server.hasArg("run_upload_ok");
  int web_cc,web_setro,web_lcdbl,web_upt,web_dhten,web_cc_name;
  String web_city_name;

  if (server.hasArg("web_city_name") || server.hasArg("web_ccode") || server.hasArg("web_bl") ||
      server.hasArg("web_upwe_t") || server.hasArg("web_DHT11_en") || server.hasArg("web_set_rotation"))
  {
    web_city_name = server.arg("web_city_name");
    web_cc_name = getCityCodeByName(web_city_name);
    web_cc = server.arg("web_ccode").toInt();
    if(web_cc_name>=101000000 && web_cc_name<=102000000) web_cc = web_cc_name;
    web_setro = server.arg("web_set_rotation").toInt();
    web_lcdbl = server.arg("web_bl").toInt();
    web_upt = server.arg("web_upwe_t").toInt();
    web_dhten = server.arg("web_DHT11_en").toInt();

    if(web_cc>=101000000 && web_cc<=102000000)
    {
      saveCityCodetoEEP(&web_cc);
      readCityCodefromEEP(&web_cc);
      cityCode = web_cc;
      UpdateWeater_en = 1;
      weaterTime = 0;
    }
    if(web_lcdbl>0 && web_lcdbl<=100)
    {
      EEPROM.write(BL_addr, web_lcdbl);
      EEPROM.commit();
      delay(5);
      LCD_BL_PWM = EEPROM.read(BL_addr);
      delay(5);
      analogWrite(LCD_BL_PIN, 1023 - (LCD_BL_PWM*10));
    }
    if(web_upt > 0 && web_upt <= 60)
    {
      EEPROM.write(UpWeT_addr, web_upt);
      EEPROM.commit();
      delay(5);
      updateweater_time = web_upt;
    }

    EEPROM.write(DHT_addr, web_dhten);
    EEPROM.commit();
    delay(5);
    if(web_dhten != DHT_img_flag)
    {
      DHT_img_flag = web_dhten;
      tft.fillScreen(0x0000);
      indoorAvatarDirty = 1;
      LCD_reflash(1);
      UpdateWeater_en = 1;
      TJpgDec.drawJpg(15,183,temperature, sizeof(temperature));
      TJpgDec.drawJpg(15,213,humidity, sizeof(humidity));
    }

    EEPROM.write(Ro_addr, web_setro);
    EEPROM.commit();
    delay(5);
    if(web_setro != LCD_Rotation)
    {
      LCD_Rotation = web_setro;
      tft.setRotation(LCD_Rotation);
      tft.fillScreen(0x0000);
      indoorAvatarDirty = 1;
      LCD_reflash(1);
      UpdateWeater_en = 1;
      TJpgDec.drawJpg(15,183,temperature, sizeof(temperature));
      TJpgDec.drawJpg(15,213,humidity, sizeof(humidity));
    }
  }

  String content = "<html><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'><style>";
  content += "html,body{background:#0f172a;color:#e2e8f0;font-size:22px;font-family:Arial,sans-serif;margin:0;line-height:1.6;}";
  content += ".wrap{width:100%;padding:16px;box-sizing:border-box;}fieldset{border:1px solid #334155;border-radius:10px;padding:14px;margin:12px 0;}legend{color:#7dd3fc;font-size:24px;font-weight:700;}label{display:block;margin-top:6px;}input,select{width:100%;box-sizing:border-box;padding:12px;margin:8px 0;background:#111827;color:#fff;border:1px solid #334155;border-radius:8px;font-size:22px;}.btn{width:100%;padding:14px;border:0;border-radius:8px;background:#06b6d4;color:#fff;font-weight:bold;font-size:22px;}.ver{font-size:18px;color:#93c5fd;} progress{width:100%;height:16px;}";
  content += "</style><body><div class='wrap'><form action='/' method='POST'>";
  content += "<div id='fw_ver' class='ver'></div>";

  content += "<fieldset><legend id='legend_basic'></legend>";
  content += "<label id='label_city_name'></label><input id='web_city_name' type='text' name='web_city_name' oninput='syncCityCode()'>";
  content += "<label id='label_city'></label><input id='web_ccode' type='text' name='web_ccode' value='" + cityCode + "'>";
  content += "<label id='label_bl'></label><input type='text' name='web_bl' value='" + String(LCD_BL_PWM) + "'>";
  content += "<label id='label_upt'></label><input type='text' name='web_upwe_t' value='" + String(updateweater_time) + "'>";
  content += "</fieldset>";

  content += "<fieldset><legend id='legend_adv'></legend>";
  #if DHT_EN
  content += "<label id='label_dht'></label><select id='sel_dht' name='web_DHT11_en'><option value='0'></option><option value='1'></option></select>";
  #endif
  content += "<label id='label_rot'></label><select id='sel_rot' name='web_set_rotation'><option value='0'></option><option value='1'></option><option value='2'></option><option value='3'></option></select>";
  content += "<input id='btn_save' class='btn' type='submit' value=''></fieldset></form>";

  content += "<fieldset><legend id='legend_upload'></legend>";
  content += "<form id='bootUploadForm' action='/upload_boot' method='POST' enctype='multipart/form-data'><label id='label_boot'></label><input type='file' name='boot_file' accept='image/png,image/jpeg,.png,.jpg,.jpeg'><input id='btn_boot' class='btn' type='submit' value=''></form>";
  content += "<div id='boot_upload_status' class='ver' data-ok='" + String(bootOk ? 1 : 0) + "'></div><progress id='boot_upload_progress' max='100' value='" + String(bootOk ? 100 : 0) + "'></progress>";
  content += "<form id='runUploadForm' action='/upload_run' method='POST' enctype='multipart/form-data'><label id='label_run'></label><input type='file' name='run_file' accept='image/png,image/jpeg,.png,.jpg,.jpeg'><input id='btn_run' class='btn' type='submit' value=''></form>";
  content += "<div id='run_upload_status' class='ver' data-ok='" + String(runOk ? 1 : 0) + "'></div><progress id='run_upload_progress' max='100' value='" + String(runOk ? 100 : 0) + "'></progress>";
  content += "<div id='hint_stage' class='ver'></div>";
  if(webUploadError.length() > 0) content += "<div id='upload_error' style='color:#fda4af;font-size:18px;'>" + webUploadError + "</div>";
  content += "</fieldset>";

  content += "<script>";
  content += "const RUN_W=" + String(RUN_IMG_W) + ",RUN_H=" + String(RUN_IMG_H) + ";";
  content += "const T={basic:'\u57fa\u7840\u8bbe\u7f6e',adv:'\u9ad8\u7ea7\u8bbe\u7f6e',city_name:'\u57ce\u5e02\u540d\u79f0',city:'\u57ce\u5e02\u4ee3\u7801',bl:'\u4eae\u5ea6(1-100)',upt:'\u5929\u6c14\u5237\u65b0\u95f4\u9694(\u5206\u949f)',dht:'DHT\u663e\u793a',off:'\u5173\u95ed',on:'\u5f00\u542f',rot:'\u5c4f\u5e55\u65b9\u5411',r0:'USB\u671d\u4e0a',r1:'USB\u671d\u53f3',r2:'USB\u671d\u4e0b',r3:'USB\u671d\u5de6',save:'\u4fdd\u5b58\u8bbe\u7f6e',upload:'\u56fe\u7247\u4e0a\u4f20',boot:'\u5f00\u673aLogo(PNG/JPG/JPEG)',btnBoot:'\u4e0a\u4f20\u5e76\u5e94\u7528\u5f00\u673aLogo',run:'\u8fd0\u884c\u9875\u53f3\u4e0b\u89d2\u56fe\u7247(PNG/JPG/JPEG)',btnRun:'\u4e0a\u4f20\u5e76\u5e94\u7528\u8fd0\u884c\u56fe',wait:'\u7b49\u5f85\u4e0a\u4f20',ok:'\u4e0a\u4f20\u6210\u529f',stage:'\u4e0a\u4f20\u9636\u6bb5\uff1a\u4e0a\u4f20 / \u6539\u6a21 / \u9002\u914d / \u8bbe\u7f6e\u3002\u8fd0\u884c\u56fe\u9002\u914d\u5c3a\u5bf8\uff1a'};";
  content += "function txt(id,v){var e=document.getElementById(id);if(e){if(e.tagName==='INPUT')e.value=v;else e.textContent=v;}}";
  content += "txt('fw_ver','\\u56fa\\u4ef6\\u7248\\u672c\\uff1a" + String(Version) + "');txt('legend_basic',T.basic);txt('legend_adv',T.adv);txt('label_city_name',T.city_name);txt('label_city',T.city);txt('label_bl',T.bl);txt('label_upt',T.upt);txt('label_dht',T.dht);txt('label_rot',T.rot);txt('btn_save',T.save);txt('legend_upload',T.upload);txt('label_boot',T.boot);txt('btn_boot',T.btnBoot);txt('label_run',T.run);txt('btn_run',T.btnRun);txt('hint_stage',T.stage+RUN_W+'x'+RUN_H);var ci=document.getElementById('web_city_name');if(ci)ci.placeholder='\\u4f8b\\u5982\\uff1a\\u676d\\u5dde/\\u5317\\u4eac';";
  content += "const CITY_MAP={'\\u5317\\u4eac':'101010100','\\u4e0a\\u6d77':'101020100','\\u5e7f\\u5dde':'101280101','\\u6df1\\u5733':'101280601','\\u676d\\u5dde':'101210101','\\u5357\\u4eac':'101190101','\\u6b66\\u6c49':'101200101','\\u897f\\u5b89':'101110101','\\u91cd\\u5e86':'101040100','\\u6210\\u90fd':'101270101','\\u957f\\u6c99':'101250101','\\u73e0\\u6d77':'101280701'};";
  content += "function normCity(v){v=(v||'').replace(/\\s+/g,'').trim();if(v.endsWith('市'))v=v.slice(0,-1);return v;}";
  content += "function syncCityCode(){var n=document.getElementById('web_city_name');var c=document.getElementById('web_ccode');if(!n||!c)return;var k=normCity(n.value);if(CITY_MAP[k])c.value=CITY_MAP[k];}";
  content += "var selD=document.getElementById('sel_dht');if(selD){selD.options[0].text=T.off;selD.options[1].text=T.on;selD.value='" + String(DHT_img_flag) + "';}";
  content += "var selR=document.getElementById('sel_rot');if(selR){selR.options[0].text=T.r0;selR.options[1].text=T.r1;selR.options[2].text=T.r2;selR.options[3].text=T.r3;selR.value='" + String(LCD_Rotation) + "';}";
  content += "var bs=document.getElementById('boot_upload_status');if(bs)bs.textContent=(bs.getAttribute('data-ok')==='1')?T.ok:T.wait;";
  content += "var rs=document.getElementById('run_upload_status');if(rs)rs.textContent=(rs.getAttribute('data-ok')==='1')?T.ok:T.wait;";
  content += "function loadImageFromFile(file){return new Promise(function(resolve,reject){var r=new FileReader();r.onload=function(){var img=new Image();img.onload=function(){resolve(img);};img.onerror=function(){reject(new Error('decode'));};img.src=r.result;};r.onerror=function(){reject(new Error('read'));};r.readAsDataURL(file);});}";
  content += "function canvasToBlob(canvas,quality){return new Promise(function(resolve,reject){canvas.toBlob(function(blob){if(blob)resolve(blob);else reject(new Error('convert'));},'image/jpeg',quality||0.9);});}";
  content += "async function preprocessImage(file,statusEl,targetW,targetH,fileName){if(statusEl)statusEl.textContent='\u4e0a\u4f20\u4e2d';var img=await loadImageFromFile(file);var cvs=document.createElement('canvas');var ctx=cvs.getContext('2d');if(targetW>0&&targetH>0){if(statusEl)statusEl.textContent='\u6539\u6a21\u4e2d';cvs.width=targetW;cvs.height=targetH;ctx.fillStyle='#000';ctx.fillRect(0,0,targetW,targetH);if(statusEl)statusEl.textContent='\u9002\u914d\u4e2d';var ratio=Math.min(targetW/img.width,targetH/img.height);var dw=Math.max(1,Math.round(img.width*ratio));var dh=Math.max(1,Math.round(img.height*ratio));var dx=Math.floor((targetW-dw)/2);var dy=Math.floor((targetH-dh)/2);ctx.drawImage(img,dx,dy,dw,dh);}else{cvs.width=img.width;cvs.height=img.height;ctx.drawImage(img,0,0);}var blob=await canvasToBlob(cvs,0.9);return new File([blob],fileName,{type:'image/jpeg'});}";
  content += "function bindUpload(formId,statusId,progressId){var f=document.getElementById(formId);if(!f)return;f.addEventListener('submit',async function(e){e.preventDefault();var s=document.getElementById(statusId);var p=document.getElementById(progressId);var fi=f.querySelector('input[type=file]');var files=(fi||{}).files;if(!files||files.length===0){if(s)s.textContent='\u8bf7\u9009\u62e9\u56fe\u7247\u6587\u4ef6';return;}var file=files[0];var n=(file.name||'').toLowerCase();if(!(n.endsWith('.png')||n.endsWith('.jpg')||n.endsWith('.jpeg'))){if(s)s.textContent='\u6587\u4ef6\u7c7b\u578b\u9519\u8bef\uff0c\u4ec5\u652f\u6301PNG/JPG/JPEG';return;}if(s)s.textContent='\u4e0a\u4f20\u4e2d 0%';if(p)p.value=0;var uploadFile=file;try{uploadFile=(formId==='runUploadForm')?await preprocessImage(file,s,RUN_W,RUN_H,'run_adapt.jpg'):await preprocessImage(file,s,200,70,'boot_200x70.jpg');}catch(ex){if(s)s.textContent='\u5904\u7406\u5931\u8d25';return;}if(s)s.textContent='\u8bbe\u7f6e\u4e2d';var xhr=new XMLHttpRequest();xhr.open('POST',f.action,true);xhr.upload.onprogress=function(ev){if(ev.lengthComputable){var v=Math.min(100,Math.round(ev.loaded*100/ev.total));if(p)p.value=v;if(s)s.textContent='\u4e0a\u4f20\u4e2d '+v+'%';}};xhr.onreadystatechange=function(){if(xhr.readyState===4){if(xhr.status===200){if(p)p.value=100;if(s)s.textContent='\u8bbe\u7f6e\u5b8c\u6210';setTimeout(function(){if(s)s.textContent='\u4e0a\u4f20\u6210\u529f';if(formId==='bootUploadForm'){location.href='/?boot_upload_ok=1';}else{location.href='/?run_upload_ok=1';}},500);}else{if(s)s.textContent='\u4e0a\u4f20\u5931\u8d25';}}};var fd=new FormData();fd.append((formId==='bootUploadForm')?'boot_file':'run_file',uploadFile,uploadFile.name||'upload.jpg');xhr.send(fd);});}";
  content += "syncCityCode();bindUpload('bootUploadForm','boot_upload_status','boot_upload_progress');bindUpload('runUploadForm','run_upload_status','run_upload_progress');";
  content += "</script>";
  content += "</div></body></html>";
  server.send(200, "text/html", content);
}


void handleNotFound() {
  String message = "File Not Found\n\n";
  message += "URI: ";
  message += server.uri();
  message += "\nMethod: ";
  message += (server.method() == HTTP_GET) ? "GET" : "POST";
  message += "\nArguments: ";
  message += server.args();
  message += "\n";
  for (uint8_t i = 0; i < server.args(); i++) {
    message += " " + server.argName(i) + ": " + server.arg(i) + "\n";
  }
  server.send(404, "text/plain", message);
}


void handleBootUpload()
{
  HTTPUpload& upload = server.upload();
  if(upload.status == UPLOAD_FILE_START)
  {
    webUploadError = "";
    webUploadBytes = 0;
    webWrittenBytes = 0;
    if(!isJpgFileName(upload.filename)) { webUploadError = "Upload failed: JPG/JPEG only"; return; }
    webUploadFile = LittleFS.open("/boot.jpg", "w");
    if(!webUploadFile) webUploadError = "Upload failed: FS open error";
  }
  else if(upload.status == UPLOAD_FILE_WRITE)
  {
    if(webUploadFile)
    {
      size_t wr = webUploadFile.write(upload.buf, upload.currentSize);
      webUploadBytes += upload.currentSize;
      webWrittenBytes += (uint32_t)wr;
    }
  }
  else if(upload.status == UPLOAD_FILE_END)
  {
    if(webUploadFile) webUploadFile.close();
    if(webUploadError.length()==0 && webWrittenBytes < webUploadBytes) webUploadError = "Upload failed: file too large or no space";
    if(webUploadError.length() == 0)
    {
      String verifyErr = "";
      if(!validateUploadedJpeg("/boot.jpg", verifyErr)) webUploadError = verifyErr;
      else {
        bootLogoDrawn = 0;
      }
    }
  }
  else if(upload.status == UPLOAD_FILE_ABORTED)
  {
    if(webUploadFile) webUploadFile.close();
    webUploadError = "Upload failed: aborted";
  }
}

void handleRunUpload()
{
  HTTPUpload& upload = server.upload();
  if(upload.status == UPLOAD_FILE_START)
  {
    webUploadError = "";
    webUploadBytes = 0;
    webWrittenBytes = 0;
    if(!isJpgFileName(upload.filename)) { webUploadError = "Upload failed: JPG/JPEG only"; return; }
    webUploadFile = LittleFS.open("/run.jpg", "w");
    if(!webUploadFile) webUploadError = "Upload failed: FS open error";
  }
  else if(upload.status == UPLOAD_FILE_WRITE)
  {
    if(webUploadFile)
    {
      size_t wr = webUploadFile.write(upload.buf, upload.currentSize);
      webUploadBytes += upload.currentSize;
      webWrittenBytes += (uint32_t)wr;
    }
  }
  else if(upload.status == UPLOAD_FILE_END)
  {
    if(webUploadFile) webUploadFile.close();
    if(webUploadError.length()==0 && webWrittenBytes < webUploadBytes) webUploadError = "Upload failed: file too large or no space";
    if(webUploadError.length() == 0)
    {
      String verifyErr = "";
      if(!validateUploadedJpeg("/run.jpg", verifyErr)) webUploadError = verifyErr;
      else {
        indoorAvatarDirty = 1;
        drawRuntimeCornerImage();
      }
    }
  }
  else if(upload.status == UPLOAD_FILE_ABORTED)
  {
    if(webUploadFile) webUploadFile.close();
    webUploadError = "Upload failed: aborted";
  }
}

void Web_Sever_Init()
{
  uint32_t counttime = 0;
  Serial.println("mDNS responder building...");
  counttime = millis();
  while (!MDNS.begin("SD3"))
  {
    if(millis() - counttime > 30000) ESP.restart();
  }

  Serial.println("mDNS responder started");




  server.on("/", handleconfig);
  server.on("/upload_boot", HTTP_POST, [](){ if(webUploadError.length() == 0) server.send(200, "text/plain", "OK"); else server.send(400, "text/plain", webUploadError); }, handleBootUpload);
  server.on("/upload_run", HTTP_POST, [](){ if(webUploadError.length() == 0) server.send(200, "text/plain", "OK"); else server.send(400, "text/plain", webUploadError); }, handleRunUpload);
  server.onNotFound(handleNotFound);


  server.begin();
  Serial.println("HTTP服务器已开启"); Serial.print("????: http://");
  Serial.println(WiFi.localIP());

  MDNS.addService("http", "tcp", 80);
}

void Web_Sever()
{
  MDNS.update();
  server.handleClient();
}

void Web_sever_Win()
{
  String ip_url = WiFi.localIP().toString();
  clk.setColorDepth(8);

  clk.createSprite(220, 92);
  clk.fillSprite(0x0000);

  clk.setTextDatum(CC_DATUM);
  clk.setTextColor(TFT_GREEN, 0x0000);
  clk.drawString("Service IP:",110,16,4);

  clk.setTextColor(TFT_WHITE, 0x0000);
  clk.drawString(ip_url,110,58,4);
  clk.pushSprite(10,30);

  clk.deleteSprite();
}
#endif

#if WM_EN

void Web_win()
{
  clk.setColorDepth(8);

  clk.createSprite(220, 110);
  clk.fillSprite(0x0000);

  clk.setTextDatum(CC_DATUM);
  clk.setTextColor(TFT_GREEN, 0x0000);
  clk.drawString("Pls Connect WiFi",110,16,4);
  clk.drawString("SSID:",110,52,4);
  clk.setTextColor(TFT_WHITE, 0x0000);
  clk.drawString("AutoConnectAP",110,86,4);
  clk.pushSprite(10,20);

  clk.deleteSprite();
}


void Webconfig()
{
  WiFi.mode(WIFI_STA);

  delay(3000);
  wm.resetSettings();


  int customFieldLength = 40;
# 1033 "F:/05.理财/31.商品/10.正式商品化/07.WIFI天气小时钟SmallDesktopDisplay/2.Firmware/MCSmallDesktopDisplay/MCSmallDesktopDisplay.ino"
  const char* set_rotation = "<br/><label for='set_rotation'>Set Rotation</label>\
                              <input type='radio' name='set_rotation' value='0' checked> One<br>\
                              <input type='radio' name='set_rotation' value='1'> Two<br>\
                              <input type='radio' name='set_rotation' value='2'> Three<br>\
                              <input type='radio' name='set_rotation' value='3'> Four<br>";
  WiFiManagerParameter custom_rot(set_rotation);
  WiFiManagerParameter custom_bl("LCDBL","LCD BackLight(1-100)","10",3);
  #if DHT_EN
  WiFiManagerParameter custom_DHT11_en("DHT11_en","Enable DHT11 sensor","0",1);
  #endif
  WiFiManagerParameter custom_weatertime("WeaterUpdateTime","Weather Update Time(Min)","10",3);
  WiFiManagerParameter custom_cc("CityCode","CityCode","101010100",9);
  WiFiManagerParameter p_lineBreak_notext("<p></p>");



  wm.addParameter(&p_lineBreak_notext);
  wm.addParameter(&custom_cc);
  wm.addParameter(&p_lineBreak_notext);
  wm.addParameter(&custom_bl);
  wm.addParameter(&p_lineBreak_notext);
  wm.addParameter(&custom_weatertime);
  wm.addParameter(&p_lineBreak_notext);
  wm.addParameter(&custom_rot);
  #if DHT_EN
  wm.addParameter(&p_lineBreak_notext);
  wm.addParameter(&custom_DHT11_en);
  #endif
  wm.setSaveParamsCallback(saveParamCallback);






  std::vector<const char *> menu = {"wifi","param","restart"};
  wm.setMenu(menu);


  wm.setClass("invert");







  wm.setConfigPortalTimeout(300);

  wm.setAPClientCheck(true);



  wm.setMinimumSignalQuality(20);





  bool res;

   res = wm.autoConnect("AutoConnectAP");


  while(!res);
}

String getParam(String name){

  String value;
  if(wm.server->hasArg(name)) {
    value = wm.server->arg(name);
  }
  return value;
}

void saveParamCallback(){
  int cc;

  Serial.println("[CALLBACK] saveParamCallback fired");
# 1121 "F:/05.理财/31.商品/10.正式商品化/07.WIFI天气小时钟SmallDesktopDisplay/2.Firmware/MCSmallDesktopDisplay/MCSmallDesktopDisplay.ino"
  #if DHT_EN
  DHT_img_flag = getParam("DHT11_en").toInt();
  #endif
  updateweater_time = getParam("WeaterUpdateTime").toInt();
  cc = getParam("CityCode").toInt();
  LCD_Rotation = getParam("set_rotation").toInt();
  LCD_BL_PWM = getParam("LCDBL").toInt();



  Serial.print("CityCode = ");
  Serial.println(cc);
  if(cc>=101000000 && cc<=102000000 || cc == 0)
  {
    saveCityCodetoEEP(&cc);







    readCityCodefromEEP(&cc);






    cityCode = cc;
  }

  Serial.print("LCD_Rotation = ");
  Serial.println(LCD_Rotation);
  if(EEPROM.read(Ro_addr) != LCD_Rotation)
  {
    EEPROM.write(Ro_addr, LCD_Rotation);
    EEPROM.commit();
    delay(5);
  }
  tft.setRotation(LCD_Rotation);
  tft.fillScreen(0x0000);
  Web_win();
  loadNum--;
  loading(1);
  if(EEPROM.read(BL_addr) != LCD_BL_PWM)
  {
    EEPROM.write(BL_addr, LCD_BL_PWM);
    EEPROM.commit();
    delay(5);
  }

  Serial.printf("亮度调整为：");
  analogWrite(LCD_BL_PIN, 1023 - (LCD_BL_PWM*10));
  Serial.println(LCD_BL_PWM);

  Serial.printf("天气更新时间调整为：");
  Serial.println(updateweater_time);

  #if DHT_EN

  Serial.printf("DHT11传感器：");
  EEPROM.write(DHT_addr, DHT_img_flag);
  EEPROM.commit();
  Serial.println((DHT_img_flag?"已启用":"未启用"));
  #endif
}
#endif





void setup()
{
  Serial.begin(115200);
  EEPROM.begin(1024);
  if(!LittleFS.begin()) Serial.println("LittleFS init failed");



 #if DHT_EN
  dht.begin();

  DHT_img_flag = EEPROM.read(DHT_addr);
 #endif

  if(EEPROM.read(BL_addr)>0&&EEPROM.read(BL_addr)<100)
    LCD_BL_PWM = EEPROM.read(BL_addr);
  pinMode(LCD_BL_PIN, OUTPUT);
  analogWrite(LCD_BL_PIN, 1023 - (LCD_BL_PWM*10));

  if(EEPROM.read(Ro_addr)>=0&&EEPROM.read(Ro_addr)<=3)
    LCD_Rotation = EEPROM.read(Ro_addr);


  updateweater_time = EEPROM.read(UpWeT_addr);



  tft.begin();
  tft.invertDisplay(1);
  tft.setRotation(LCD_Rotation);
  tft.fillScreen(0x0000);
  indoorAvatarDirty = 1;
  tft.setTextColor(TFT_BLACK, bgColor);

  targetTime = millis() + 1000;
  readwificonfig();
  Serial.print("正在连接WIFI ");
  Serial.println(wificonf.stassid);
  WiFi.begin(wificonf.stassid, wificonf.stapsw);

  TJpgDec.setJpgScale(1);
  TJpgDec.setSwapBytes(true);
  TJpgDec.setCallback(tft_output);

  while (WiFi.status() != WL_CONNECTED)
  {
    loading(30);

    if(loadNum>=194)
    {

      #if WM_EN
      Web_win();
      Webconfig();
      #endif

      #if !WM_EN
      SmartConfig();
      #endif
      break;
    }
  }
  delay(10);
  while(loadNum < 194)
  {
    loading(1);
  }

  if(WiFi.status() == WL_CONNECTED)
  {




    strcpy(wificonf.stassid,WiFi.SSID().c_str());
    strcpy(wificonf.stapsw,WiFi.psk().c_str());
    savewificonfig();
    readwificonfig();
    #if WebSever_EN

    Web_Sever_Init();
    Web_sever_Win();
    delay(10000);
    #endif
  }



  Serial.println("启动UDP");
  Udp.begin(localPort);
  Serial.println("等待同步...");
  setSyncProvider(getNtpTime);
  setSyncInterval(300);



  TJpgDec.setJpgScale(1);
  TJpgDec.setSwapBytes(true);
  TJpgDec.setCallback(tft_output);

  int CityCODE = 0;
  readCityCodefromEEP(&CityCODE);






  if(CityCODE>=101000000 && CityCODE<=102000000)
    cityCode = CityCODE;
  else
    getCityCode();

  tft.fillScreen(TFT_BLACK);
  indoorAvatarDirty = 1;

  TJpgDec.drawJpg(15,183,temperature, sizeof(temperature));
  TJpgDec.drawJpg(15,213,humidity, sizeof(humidity));

  getCityWeater();
#if DHT_EN
  if(DHT_img_flag != 0)
  IndoorTem();
#endif
#if !WebSever_EN
  WiFi.forceSleepBegin();
  Serial.println("WIFI休眠......");
  Wifi_en = 0;
#endif
}



void loop()
{
  #if WebSever_EN
  Web_Sever();
  #endif
  LCD_reflash(0);
  Serial_set();
}

void LCD_reflash(int en)
{
  if (now() != prevDisplay || en == 1)
  {
    prevDisplay = now();
    digitalClockDisplay(en);
    prevTime=0;
  }


  if(second()%2 ==0&& prevTime == 0 || en == 1){
#if DHT_EN
    if(DHT_img_flag != 0)
    IndoorTem();
#endif
    scrollBanner();
  }
#if imgAst_EN
  if(DHT_img_flag == 0)
  {
    if(LittleFS.exists("/run.jpg"))
    {
      if(indoorAvatarDirty)
      {
        drawRuntimeCornerImage();
        indoorAvatarDirty = 0;
      }
    }
    else
    {
      imgAnim();
    }
  }
#endif


  if(millis() - weaterTime > (60000*updateweater_time) || en == 1 || UpdateWeater_en != 0){
    if(Wifi_en == 0)
    {
      WiFi.forceSleepWake();
      Serial.println("WIFI恢复......");
      Wifi_en = 1;
    }

    if(WiFi.status() == WL_CONNECTED)
    {

      getCityWeater();
      if(UpdateWeater_en != 0) UpdateWeater_en = 0;
      weaterTime = millis();

      getNtpTime();
      #if !WebSever_EN
      WiFi.forceSleepBegin();
      Serial.println("WIFI休眠......");
      Wifi_en = 0;
      #endif
    }
  }
}


void getCityCode(){
 String URL = "http://wgeo.weather.com.cn/ip/?_="+String(now());

  HTTPClient httpClient;


  httpClient.begin(wificlient,URL);


  httpClient.setUserAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1");
  httpClient.addHeader("Referer", "http://www.weather.com.cn/");


  int httpCode = httpClient.GET();
  Serial.print("Send GET request to URL: ");
  Serial.println(URL);


  if (httpCode == HTTP_CODE_OK) {
    String str = httpClient.getString();

    int aa = str.indexOf("id=");
    if(aa>-1)
    {

       cityCode = str.substring(aa+4,aa+4+9);
       Serial.println(cityCode);
       getCityWeater();
    }
    else
    {
      Serial.println("获取城市代码失败");
    }


  } else {
    Serial.println("请求城市代码错误：");
    Serial.println(httpCode);
  }


  httpClient.end();
}




void getCityWeater(){

 String URL = "http://d1.weather.com.cn/weather_index/" + cityCode + ".html?_="+String(now());

  HTTPClient httpClient;

  httpClient.begin(URL);


  httpClient.setUserAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1");
  httpClient.addHeader("Referer", "http://www.weather.com.cn/");


  int httpCode = httpClient.GET();
  Serial.println("正在获取天气数据");
  Serial.println(URL);


  if (httpCode == HTTP_CODE_OK) {

    String str = httpClient.getString();
    int indexStart = str.indexOf("weatherinfo\":");
    int indexEnd = str.indexOf("};var alarmDZ");

    String jsonCityDZ = str.substring(indexStart+13,indexEnd);



    indexStart = str.indexOf("alarmDZ ={\"w\":[");
    indexEnd = str.indexOf("]};var dataSK");
    String jsonDataWarn1 = str.substring(indexStart+15,indexEnd);
    Serial.println("1="+jsonDataWarn1);
    if(jsonDataWarn1.length() >= 40) {
      Warn_Flag = 1;
    }
    else {
      Warn_Flag = 0;
    }

    indexStart = str.indexOf("dataSK =");
    indexEnd = str.indexOf(";var dataZS");
    String jsonDataSK = str.substring(indexStart+8,indexEnd);



    indexStart = str.indexOf("\"f\":[");
    indexEnd = str.indexOf(",{\"fa");
    String jsonFC = str.substring(indexStart+5,indexEnd);




    weaterData(&jsonCityDZ,&jsonDataSK,&jsonFC,&jsonDataWarn1);
    Serial.println("获取成功");

  } else {
    Serial.println("请求城市天气错误：");
    Serial.print(httpCode);
  }



  httpClient.end();
}


String scrollText[7];


void weaterData(String *cityDZ,String *dataSK,String *dataFC,String *dataWarn1)
{

  DynamicJsonDocument doc(1024);
  deserializeJson(doc, *dataSK);
  JsonObject sk = doc.as<JsonObject>();




  clk.setColorDepth(8);
  clk.loadFont(ZdyLwFont_20);


  clk.createSprite(58, 24);
  clk.fillSprite(bgColor);
  clk.setTextDatum(CC_DATUM);
  clk.setTextColor(TFT_WHITE, bgColor);
  clk.drawString(sk["temp"].as<String>()+"℃",28,13);
  clk.pushSprite(100,184);
  clk.deleteSprite();
  tempnum = sk["temp"].as<int>();
  tempnum = tempnum+10;
  if(tempnum<10)
    tempcol=0x00FF;
  else if(tempnum<28)
    tempcol=0x0AFF;
  else if(tempnum<34)
    tempcol=0x0F0F;
  else if(tempnum<41)
    tempcol=0xFF0F;
  else if(tempnum<49)
    tempcol=0xF00F;
  else
  {
    tempcol=0xF00F;
    tempnum=50;
  }
  tempWin();


  clk.createSprite(58, 24);
  clk.fillSprite(bgColor);
  clk.setTextDatum(CC_DATUM);
  clk.setTextColor(TFT_WHITE, bgColor);
  clk.drawString(sk["SD"].as<String>(),28,13);

  clk.pushSprite(100,214);
  clk.deleteSprite();

  huminum = atoi((sk["SD"].as<String>()).substring(0,2).c_str());

  if(huminum>90)
    humicol=0x00FF;
  else if(huminum>70)
    humicol=0x0AFF;
  else if(huminum>40)
    humicol=0x0F0F;
  else if(huminum>20)
    humicol=0xFF0F;
  else
    humicol=0xF00F;
  humidityWin();



  clk.createSprite(94, 30);
  clk.fillSprite(bgColor);
  clk.setTextDatum(CC_DATUM);
  clk.setTextColor(TFT_WHITE, bgColor);
  clk.drawString(sk["cityname"].as<String>(),44,16);
  clk.pushSprite(15,15);
  clk.deleteSprite();


  uint16_t pm25BgColor = tft.color565(156,202,127);
  String aqiTxt = "优";
  int pm25V = sk["aqi"];
  if(pm25V>200){
    pm25BgColor = tft.color565(136,11,32);
    aqiTxt = "重度";
  }else if(pm25V>150){
    pm25BgColor = tft.color565(186,55,121);
    aqiTxt = "中度";
  }else if(pm25V>100){
    pm25BgColor = tft.color565(242,159,57);
    aqiTxt = "轻度";
  }else if(pm25V>50){
    pm25BgColor = tft.color565(247,219,100);
    aqiTxt = "良";
  }
  clk.createSprite(56, 24);
  clk.fillSprite(bgColor);
  clk.fillRoundRect(0,0,50,24,4,pm25BgColor);
  clk.setTextDatum(CC_DATUM);
  clk.setTextColor(0x0000);
  clk.drawString(aqiTxt,25,13);
  clk.pushSprite(104,18);
  clk.deleteSprite();

  scrollText[0] = "实时天气 "+sk["weather"].as<String>();
  scrollText[1] = "空气质量 "+aqiTxt;
  scrollText[2] = "风向 "+sk["WD"].as<String>()+sk["WS"].as<String>();




  wrat.printfweather(170,15,atoi((sk["weathercode"].as<String>()).substring(1,3).c_str()));




  deserializeJson(doc, *cityDZ);
  JsonObject dz = doc.as<JsonObject>();





  scrollText[3] = "今日"+dz["weather"].as<String>();

  deserializeJson(doc, *dataFC);
  JsonObject fc = doc.as<JsonObject>();

  scrollText[4] = "最低温度"+fc["fd"].as<String>()+"℃";
  scrollText[5] = "最高温度"+fc["fc"].as<String>()+"℃";




  deserializeJson(doc, *dataWarn1);
  JsonObject dataWarnjson1 = doc.as<JsonObject>();
  Warn_Number1 = dataWarnjson1["w4"].as<int>();
  Warn_Value1 = dataWarnjson1["w6"].as<int>();

  Serial.println("气象预警编号1：" + String(Warn_Number1) + " 等级1：" + String(Warn_Value1));
# 1661 "F:/05.理财/31.商品/10.正式商品化/07.WIFI天气小时钟SmallDesktopDisplay/2.Firmware/MCSmallDesktopDisplay/MCSmallDesktopDisplay.ino"
  uint16_t weatherWarnBgColor1;
  switch(Warn_Value1) {

    case 1:weatherWarnBgColor1 = tft.color565(0,128,255);break;
    case 2:weatherWarnBgColor1 = tft.color565(255,204,51);break;
    case 3:weatherWarnBgColor1 = tft.color565(255,153,0);break;
    case 4:weatherWarnBgColor1 = tft.color565(255,0,0);break;
    default:Serial.println("NULL");break;
  }


    if(dataWarnjson1["w5"].as<String>() != "null") {
      clk.loadFont(ZdyLwFont_20);
      clk.createSprite(90, 24);
      clk.fillSprite(bgColor);
      clk.fillRoundRect(0,0,90,24,5,weatherWarnBgColor1);
      clk.setTextDatum(CC_DATUM);
      clk.setTextColor(TFT_WHITE);
      clk.drawString(dataWarnjson1["w5"].as<String>(),45,14);

      clk.pushSprite(145,145);
      clk.deleteSprite();
      clk.unloadFont();
      clk.unloadFont();
    }

  clk.unloadFont();
}

int currentIndex = 0;
TFT_eSprite clkb = TFT_eSprite(&tft);

void scrollBanner(){



    if(scrollText[currentIndex])
    {
      clkb.setColorDepth(8);
      clkb.loadFont(ZdyLwFont_20);
      clkb.createSprite(150, 30);
      clkb.fillSprite(bgColor);
      clkb.setTextWrap(false);
      clkb.setTextDatum(CC_DATUM);
      clkb.setTextColor(TFT_WHITE, bgColor);
      clkb.drawString(scrollText[currentIndex],74, 16);
      clkb.pushSprite(10,45);

      clkb.deleteSprite();
      clkb.unloadFont();

      if(currentIndex>=5)
        currentIndex = 0;
      else
        currentIndex += 1;
    }
    prevTime = 1;

}
#if imgAst_EN
void imgAnim()
{
  int x=160,y=170;
  if(millis() - AprevTime > 37)
  {
    Anim++;
    AprevTime = millis();
  }
  if(Anim==10)
    Anim=0;

  switch(Anim)
  {
    case 0:
      TJpgDec.drawJpg(x,y,i0, sizeof(i0));
      break;
    case 1:
      TJpgDec.drawJpg(x,y,i1, sizeof(i1));
      break;
    case 2:
      TJpgDec.drawJpg(x,y,i2, sizeof(i2));
      break;
    case 3:
      TJpgDec.drawJpg(x,y,i3, sizeof(i3));
      break;
    case 4:
      TJpgDec.drawJpg(x,y,i4, sizeof(i4));
      break;
    case 5:
      TJpgDec.drawJpg(x,y,i5, sizeof(i5));
      break;
    case 6:
      TJpgDec.drawJpg(x,y,i6, sizeof(i6));
      break;
    case 7:
      TJpgDec.drawJpg(x,y,i7, sizeof(i7));
      break;
    case 8:
      TJpgDec.drawJpg(x,y,i8, sizeof(i8));
      break;
    case 9:
      TJpgDec.drawJpg(x,y,i9, sizeof(i9));
      break;
    default:
      Serial.println("显示Anim错误");
      break;
  }
}
#endif

unsigned char Hour_sign = 60;
unsigned char Minute_sign = 60;
unsigned char Second_sign = 60;
void digitalClockDisplay(int reflash_en)
{
  int timey=82;
  if(hour()!=Hour_sign || reflash_en == 1)
  {
    dig.printfW3660(20,timey,hour()/10);
    dig.printfW3660(60,timey,hour()%10);
    Hour_sign = hour();
  }
  if(minute()!=Minute_sign || reflash_en == 1)
  {
    dig.printfO3660(101,timey,minute()/10);
    dig.printfO3660(141,timey,minute()%10);
    Minute_sign = minute();
  }
  if(second()!=Second_sign || reflash_en == 1)
  {
    dig.printfW1830(182,timey+30,second()/10);
    dig.printfW1830(202,timey+30,second()%10);
    Second_sign = second();
  }

  if(reflash_en == 1) reflash_en = 0;

  clk.setColorDepth(8);
  clk.loadFont(ZdyLwFont_20);


  clk.createSprite(58, 30);
  clk.fillSprite(bgColor);
  clk.setTextDatum(CC_DATUM);
  clk.setTextColor(TFT_WHITE, bgColor);
  clk.drawString(week(),29,16);
  clk.pushSprite(86,150);
  clk.deleteSprite();


  clk.createSprite(95, 30);
  clk.fillSprite(bgColor);
  clk.setTextDatum(CC_DATUM);
  clk.setTextColor(TFT_WHITE, bgColor);
  clk.drawString(monthDay(),49,16);
  clk.pushSprite(2,150);
  clk.deleteSprite();

  clk.unloadFont();

}


String week()
{
  String wk[7] = {"日","一","二","三","四","五","六"};
  String s = "周" + wk[weekday()-1];
  return s;
}


String monthDay()
{
  String s = String(month());
  s = s + "月" + day() + "日";
  return s;
}



const int NTP_PACKET_SIZE = 48;
byte packetBuffer[NTP_PACKET_SIZE];

time_t getNtpTime()
{
  IPAddress ntpServerIP;

  while (Udp.parsePacket() > 0) ;


  WiFi.hostByName(ntpServerName, ntpServerIP);



  sendNTPpacket(ntpServerIP);
  uint32_t beginWait = millis();
  while (millis() - beginWait < 1500) {
    int size = Udp.parsePacket();
    if (size >= NTP_PACKET_SIZE) {
      Serial.println("Receive NTP Response");
      Udp.read(packetBuffer, NTP_PACKET_SIZE);
      unsigned long secsSince1900;

      secsSince1900 = (unsigned long)packetBuffer[40] << 24;
      secsSince1900 |= (unsigned long)packetBuffer[41] << 16;
      secsSince1900 |= (unsigned long)packetBuffer[42] << 8;
      secsSince1900 |= (unsigned long)packetBuffer[43];

      return secsSince1900 - 2208988800UL + timeZone * SECS_PER_HOUR;
    }
  }
  Serial.println("No NTP Response :-(");
  return 0;
}


void sendNTPpacket(IPAddress &address)
{

  memset(packetBuffer, 0, NTP_PACKET_SIZE);


  packetBuffer[0] = 0b11100011;
  packetBuffer[1] = 0;
  packetBuffer[2] = 6;
  packetBuffer[3] = 0xEC;

  packetBuffer[12] = 49;
  packetBuffer[13] = 0x4E;
  packetBuffer[14] = 49;
  packetBuffer[15] = 52;


  Udp.beginPacket(address, 123);
  Udp.write(packetBuffer, NTP_PACKET_SIZE);
  Udp.endPacket();
}